package controller

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/model"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

func TestBillingTokensFromLedgerFallsBackToTaskData(t *testing.T) {
	oldDB := model.DB
	t.Cleanup(func() {
		model.DB = oldDB
	})

	dsn := "file:" + strings.ReplaceAll(t.Name(), "/", "_") + "?mode=memory&cache=shared"
	db, err := gorm.Open(sqlite.Open(dsn), &gorm.Config{})
	require.NoError(t, err)
	model.DB = db
	require.NoError(t, db.AutoMigrate(&model.Task{}))

	task := &model.Task{
		TaskID: "task_legacy_zero_tokens",
		Data:   json.RawMessage(`{"usage":{"completion_tokens":50638,"total_tokens":50638,"tool_usage":{"web_search":0}}}`),
	}
	require.NoError(t, db.Create(task).Error)

	tokens := billingTokensFromLedger(&model.BillingLedger{
		BillingID:        task.TaskID,
		BillingType:      model.BillingLedgerTypeTask,
		SourceTaskID:     task.TaskID,
		PromptTokens:     0,
		CompletionTokens: 0,
	})

	require.EqualValues(t, 0, tokens.PromptTokens)
	require.EqualValues(t, 50638, tokens.CompletionTokens)
	require.EqualValues(t, 50638, tokens.TotalTokens)
	require.EqualValues(t, 0, tokens.Usage["tool_usage"].(map[string]interface{})["web_search"])
}
